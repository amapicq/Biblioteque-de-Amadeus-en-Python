from bibliotheque import Bibliotheque

b = Bibliotheque()

b.ajouter_livre("1984", "George Orwell", 1949)
b.ajouter_livre("Le Petit Prince", "Antoine de Saint-Exupéry", 1943)

b.afficher_catalogue()

b.sauvegarder_json("catalogue.json")

b2 = Bibliotheque()
b2.charger_json("catalogue.json")
b2.afficher_catalogue()

b2.exporter_csv("catalogue.csv")
